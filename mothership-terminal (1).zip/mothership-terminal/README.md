# NAKATOMI CORPORATION — MOTHERSHIP TERMINAL

An in-universe terminal prop for Mothership RPG online play.

## Files

| File | Purpose |
|------|---------|
| `index.html` | Player-facing terminal — share this URL with players |
| `config.js` | All terminal data — logs, settings, profiles |
| `warden.html` | GM editor — keep this private, don't share with players |

## Quick Start

1. **Upload all 3 files** to a free host (GitHub Pages, Netlify, Cloudflare Pages)
2. **Open `warden.html`** locally (or at a secret URL) to set up your terminals
3. **Send players** to `yoursite.com/?t=default` (or whatever terminal key you set up)

## Hosting Options (all free)

### Netlify (easiest)
1. Go to [netlify.com](https://www.netlify.com), sign up
2. Drag the `mothership-terminal` folder onto the deploy area
3. Done — you get a URL like `random-name.netlify.app`

### GitHub Pages
1. Create a new repo, upload the 3 files
2. Go to Settings → Pages → Enable from `main` branch
3. Your URL: `yourusername.github.io/repo-name/`

### Cloudflare Pages
1. Go to [pages.cloudflare.com](https://pages.cloudflare.com), sign up
2. Create a project, upload files
3. Done — free custom domain support too

## How It Works

### Player URLs
- `yoursite.com/` → loads the `default` terminal
- `yoursite.com/?t=medbay` → loads the `medbay` terminal
- `yoursite.com/?t=security` → loads the `security` terminal

### Access Levels (lowest → highest)
`GENERAL → MEDICAL → SCIENCE → SECURITY → COMMAND`

A terminal set to MEDICAL access can see GENERAL + MEDICAL files.
Files above the terminal's access level show "ACCESS DENIED".

### Password-Locked Files
Players must type the exact password. Hide passwords as in-game clues.

### Terminal Commands
| Command | Action |
|---------|--------|
| `HELP` | Show available commands |
| `LIST` | Show accessible files |
| `OPEN filename` | Open a specific file |
| `INFO` | Show terminal info |
| `CLEAR` | Clear the screen |
| `REBOOT` | Restart with boot sequence |

Players can also **click filenames** directly from the LIST output.

## Updating Content Mid-Session

1. Open `warden.html`, make your changes
2. Click **EXPORT CONFIG** → **DOWNLOAD config.js**
3. Replace `config.js` on your host (re-deploy on Netlify/push to GitHub)
4. Tell players to refresh their browser

## Tips

- **Create different terminal keys for different locations** — `?t=bridge`, `?t=medbay`, `?t=engineering`
- **Use passwords for plot reveals** — hide the password somewhere in the module
- **Access levels gate content** — a general terminal won't show security files even if they exist
- **The boot sequence sells the prop** — customise the terminal name per location
- **Keep warden.html private** — players should never see the editor
